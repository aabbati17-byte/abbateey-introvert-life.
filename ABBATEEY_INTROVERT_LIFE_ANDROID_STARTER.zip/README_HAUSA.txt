ABBATEEY INTROVERT LIFE - ANDROID STARTER

Wannan kunshin yana dauke da Android WebView project da GitHub Actions workflow domin gina APK.

MUHIMMI:
- Wannan starter yana bude shafin app din da ke intanet:
  https://abbateey-introvert-life-4yxdk5.v2.appdeploy.ai/
- Ba a saka cikakken littafin cikin APK a matsayin offline content ba tukuna.
- Don haka wannan sigar tana bukatar internet. Kada a dauke ta a matsayin cikakken offline APK.

YADDA ZA A YI AMFANI:
1. Cire (extract) wannan ZIP.
2. Loda dukkan abubuwan da ke ciki zuwa GitHub repository dinka.
3. GitHub Actions zai gina APK idan workflow ya fara.
4. A sauke APK daga Artifacts na GitHub Actions.

Kada ka taba raba password ko verification code na GitHub.
